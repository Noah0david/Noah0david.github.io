from random import randint
from matplotlib.pyplot import *
from math import sqrt
from csvreader import *

table= importCSV('laposte_boiterue.csv', separateur =',')

def distance(P,Q):
    return sqrt((P[0]-Q[0])**2+(P[1]-Q[1])**2)

def distanceMinimale(L) :
    n = len(L)
    minimum = 1e99#distance (L[0], L[1])
    indices = [-1,-1]
    i = 0
    while i < n :
        j = i+1
        while j < n :
            a = distance( L[i], L[j])
            if a < minimum :
                minimum = a
                indices = [i,j]
            j +=1
        i += 1
    return minimum, indices

def pointAbscisseMinimale(L) :
    indice = 0
    xMin, yMin = L[0]
    for (x, y) in L:
        if x < xMin:
            indice = L.index((x,y))
            xMin, yMin = x, y
        elif x == xMin and y < yMin:
            indice = L.index((x,y))
            xMin, yMin = x, y
    return indice, xMin, yMin            

def vecteur(P, Q):
    return (Q[0]-P[0], Q[1]-P[1])

def orientation(P, Q, R):
    PQ = vecteur(P, Q)
    PR = vecteur(P, R)
    det = PQ[0]*PR[1]-PQ[1]*PR[0]
    if det > 0: return 1
    elif det == 0: return 0
    else: return -1

def triNuage(L):
    return sorted(L, key = lambda k: (k[0],k[1]))

def grahamAndrew( L ) :
    L = triNuage( L )
    EnvSup = []
    EnvInf = []
    for i in range(len(L)) :
        while len(EnvSup) >=2 and orientation(L[i], L[EnvSup[-1]], L[EnvSup[-2]]) <=0:
            EnvSup.pop()
        EnvSup.append(i)
        while len(EnvInf) >=2 and orientation( L[EnvInf[-2]] ,L[EnvInf[-1]], L[i]) <=0:
            EnvInf.pop()
        EnvInf.append(i)
    return EnvInf[:-1]+ EnvSup[::-1]

a = filtrerColonne(table,['CO_POSTAL','Latlong'])
triTable(a, 'CO_POSTAL')
A = []
for i in a:
    if int(i['CO_POSTAL'])//1000==74:
        x = i['Latlong'].split(',')
        print(x)
        tuple=[float(x[1]),float(x[0])]
        A.append(tuple)
#print(Liste)

#L = triNuage([(randint(0,100),randint(0,100)) for _ in range(100)])
#print(L)
#print(pointAbscisseMinimale(L))
#print(orientation(L[0],L[1],L[2]))
#print(L)
#print(triNuage(L))
L = triNuage(A)
idxEnveloppe = grahamAndrew(L)
print(idxEnveloppe)


plot([L[i][0] for i in range(len(L))] , [L[i][1] for i in range(len(L))] ,'o')
plot([L[i][0] for i in idxEnveloppe], [L[i][1] for i in idxEnveloppe],'r')
show()

