import folium, csv
from csvreader import*
# coding: utf-8

location = importCSV('hotels-de-prefectures-fr-3.csv')
table2 = importCSV('donneesTestCOVID.csv')

aaa = filtrerColonne(location,['LatDD','LonDD'])
LatDD = filtrerColonne(location,['LatDD'])
LonDD = filtrerColonne(location,['LonDD'])
commune = filtrerColonne(location,["Commune"])


tab1=filtrerColonne(location,['dep','Commune','DeptNom','LatDD','LonDD'])
tab2=filtrerColonne(table2,['dep','jour','nb_test','nb_pos'])

exportCSV(tab1, 'tab1Exporter.csv')
exportCSV(tab2, 'tab2Exporter.csv')

t1=importCSV('tab1Exporter.csv')
t2=importCSV('tab2Exporter.csv')

#print(tab1[0])
#print(t1[0])
#print(tab2[0])
#print(t2[0])
#print(t2[0])
#print(t1[3])
b=1
for i in range(2,11):
    a=str(b)
    t1[i]['dep']="0"+a
    b += 1
    #print(t1[i])
dep = filtrerColonne(t1,["dep"])

table3 = jointure(t2, t1,'dep')

exportCSV(table3, 'tableExporter.csv')
joint= importCSV('tableExporter.csv')

for i in range(37572):
    a=joint[i]['jour']
    #print(a)
    b=a.replace('-','/')
    #print(b)
    joint[i]['jour']=b

test=filtrerColonne(joint,['dep','jour','nb_test','nb_pos'])
Test = filtrerColonne(joint,['nb_test'])
PTest = filtrerColonne(joint,['nb_pos'])
Journ=filtrerColonne(joint, ['jour'])
#print(test[1]['jour'])

'''
def templateJson(data, titre):
    jsonFile ={
        "data": {
            "values": data
        },
        "repeat": {
            "layer": ["nb_test","nb_pos"]
        },
        "spec": {
            "mark": "line",

            "encoding": {

                "x": {"field": "jour", "type": "temporal"},

                "y": {"field": {"repeat": "layer"}, "type":
                    "quantitative", "title": titre},

                "color": {

                    "datum": {"repeat": "layer"},

                    "type": "nominal"
                }
            }
        }
    }

    return jsonFile
'''
#chart=templateJson(test,"test")

c= folium.Map(location=[46.227638, 2.213749], zoom_start=6) #creation de la carte
for i in range (len(aaa)): # creation d'une boucle pour la creation de mes markers
    LAT=LatDD[i] #création d'une variable qui récupère la lattitude
    LON=LonDD[i] #création d'une variable qui récupère la longitude
    COM = commune[i]  # création d'une variable qui récupère le nom de la commune correspondant a la localisation
    DEP=dep[i] #création d'une variable qui récupère le numéro de département a la localisation
    TEST=Test[i]
    TESTP=PTest[i]
    JOURN=Journ[i]
    #print(dep[i]['dep'])
    for cle in LAT.values(): #boucle sur les valeurs contenue dans LAT
        c1=cle #récupération de la valeur
        #print(cle)
    for cle in LON.values(): #boucle sur les valeurs contenue dans LON
        c2=cle #récupération de la valeur
        #print(cle)
    #print(commune[i])
    for cle in DEP.values() : #boucle sur les valeurs contenue dans DEP
        dep1= cle #récupération de la valeur

    for cle in COM.values():  # boucle sur les valeurs contenue dans COM
        com1 = cle  # récupération de la valeur

    valdep=str(dep1)+"-"+str(com1) #création d'une variable contenant le département et la commune qui vont être afficher sur les markers

    for cle in TEST.values():  # boucle sur les valeurs contenue dans TEST
        tt = cle

    for cle in TESTP.values():  # boucle sur les valeurs contenue dans TESTP
        tp = cle

    for cle in JOURN.values():  # boucle sur les valeurs contenue dans JOURN
        JJ = cle

    test_p="Jour:"+JJ+"/"+"test:" +str(tt)+"/"+"tests positifs:"+str(tp)
    folium.Marker( # création des markers

        location=[c1,c2],
        #radius=15,
        tooltip=valdep,
        popup=test_p,#templateJson(joint, "test"),
        icon=folium.Icon(color='red'),#icon_color='#FFFF00'),
        #fill=True,
    ).add_to(c)

c.save('maCarte.html')