import csv

def importCSV(fichier : str, separateur = ";"):
    tCSV = csv.DictReader(open(fichier,'r'), delimiter = separateur)
    return [dict(ligne) for ligne in tCSV]

#table= importCSV('exemple.csv')
#print(table)


def exportCSV(tableau: list, fichier: str, separateur = ";"): #definition de ma fonction
    if len(tableau) != 0: # on gère un tableau vide
        header = tableau[0].keys() # on récupère les catégories/descripteurs
        fichierCSV = csv.DictWriter(open(fichier, 'w'), fieldnames=header, delimiter = separateur)# on ouvre un fichier fichier en écriture ('w') et on dit qu'on va le "formatter"
        # format csv avec Dictwriter. Les catégories du fichier csv sont données par header.
        fichierCSV.writeheader() # on écrit les catégories/descripteurs
        for ligne in tableau: # on lit la liste de dictionnaire (ligne est un dictionnaire
            fichierCSV.writerow(ligne) #on écrit les valeurs correspondant aux catégories dans la ligne ('row')
        return None #on met un return pour le plaisir
#print(table[0]["Nom"])


def filtrerLigne(tableau : list, critere : str, valeur : str):
    filtrerTableau= []
    for indice in range(len(tableau)): #dico in tableau:
        #print(indice,tableau[indice])
        if tableau[indice][critere] == valeur:
            # on ajoute l'enregistrement numéro indice à tableauFiltrer
            filtrerTableau.append( tableau[indice])
        print(tableau[indice][critere],valeur, tableau[indice][critere] == valeur)

    return filtrerTableau

#tableFiltree = filtrerLigne(table,'Francais', '14')
#exportCSV(tableFiltree, 'maTableFiltree.csv')


#def filtrerColonne(tableau: list, listeCriteres: list):
    #filtrerTableau = []
    #for dico in tableau:
        #dicoFiltrer = {}
        #print(dico)
        #for critere in listeCriteres:
            #print(critere)
            #dicoFiltrer[critere] = dico[critere]  # on rajoute une nouvelle entrée pour chaque critère d'intérêt
        #filtrerTableau.append(dicoFiltrer)
    #return filtrerTableau

#print(filtrerColonne(table, ['Nom','Francais']))
#table2 = filtrerColonne(table, ['Nom','Francais'])
#exportCSV(table2, 'testColonne.csv')

def filtrerColonne(tableau : list, listeCriteres : list):
    filtrerTableau = []
    for dico in tableau:
        dicoFiltrer = {}
        for (cle,valeur) in dico.items():
            if cle in listeCriteres:
                dicoFiltrer[cle]=valeur
        filtrerTableau.append(dicoFiltrer)
    return filtrerTableau
#return [{cle:dico[cle] for cle in dico.keys() if cle in listeCriteres} for dico in tableau]

def triTable(tableau: list, critere: str, decroissant=False):
    return sorted(tableau, key=lambda k: k[critere], reverse=decroissant)

#tableTrier = triTable(table, 'Science')
#print(tableTrier)

#print('le carré de 4 est ' +(lambda x: str(x**2))(4))

'''
def importCSVlongue(fichier : str, separateur = ";"):
    tCSV = csv.DictReader(open(fichier,'r'), delimiter = separateur)
    tableau = []
    for ligne in tCSV:
        print(ligne)
        print(dict(ligne))
        tableau.append(dict(ligne))
    return tableau
'''
def jointure(table1, table2, descripteur):
    tableFinale = []
    for dictionnaire1 in table1: # dictionnaire1 est une variable locale de boucle
        nouveauDico = {}
        for dictionnaire2 in table2:
            if dictionnaire1[descripteur] == dictionnaire2[descripteur]:
                for (cle1, valeur1) in dictionnaire1.items():
                    nouveauDico[cle1] = valeur1
                for (cle2, valeur2) in dictionnaire2.items():
                    nouveauDico[cle2] = valeur2
                # print(nouveauDico)
                tableFinale.append(nouveauDico)
    return tableFinale


#table1 = importCSV('exemple.csv')
#table2 = importCSV('exempleAge.csv')

#table3 = jointure(table1, table2,'Nom')
#exportCSV(table3, 'tableExporter.csv')